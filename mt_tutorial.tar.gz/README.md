# Rule-based Machine Translation

Tutorial developed by Huda Khayrallah, Rebecca Knowles, Kevin Duh, and Matt Post for the
2016 JHU CLSP summer school.

  http://www.clsp.jhu.edu/workshops/16-workshop/jhu-summer-school-on-human-language-technology/
  
For installation instructions, please see: SETUP.md

Sample data is also included.

The goal is to provide something in the spirit of Kevin Knight's alignment tutorial, but updated to give students a fuller feel of both the history and challenges of MT. 
The first step in the research process is developing an understanding of the problem at hand. Novices may be interested in learning about machine translation (MT), but often lack experience and intuition about the task of translation (either by human or machine) and its challenges. The goal of this work is to allow students to interactively discover why MT is an open problem, and encourage them to ask questions, propose solutions, and test intuitions. We present a hands-on activity in which students build and evaluate their own MT systems using curated parallel texts. By having students hand-engineer MT system rules in a simple user interface, which they can then run on real data, they gain intuition about why early MT research took this approach, where it fails, and what features of language make MT a challenging problem even today. Developing translation rules typically strikes novices as an obvious approach that should succeed, but the idea quickly struggles in the face of natural language complexity. This interactive, intuition-building exercise can be augmented by a discussion of state-of-the-art MT techniques and challenges, focusing on areas or aspects of linguistic complexity that the students found difficult. We envision this lesson plan being used in the framework of a larger AI or natural language processing course (where only a small amount of time can be dedicated to MT) or as a standalone activity. We describe and release the tool that supports this lesson, as well as accompanying data.

After 90 minutes, the students should:

- Have an appreciation for the difficulties of developing rule-based systems, which will in effect have taken them through the history of rule-based approaches to MT

- Be asking questions, such as 
	- How can we automate the learning of these rules?
	- How can we make the target output more fluent?
	- How can we tell if we're actually producing better results?
	- What are some challenges that come up as you try to build translation rules?

That sets them up for an afternoon lecture introducing them to current research in MT, and its answers to these questions.

This work can be cited as follows:

@inproceedings{Khayrallah2019SIGCSE,
 author = {Khayrallah, Huda and Knowles, Rebecca and Duh, Kevin and Post, Matt},
 title = {An Interactive Teaching Tool for Introducing Novices to Machine Translation},
 booktitle = {Proceedings of the 50th ACM Technical Symposium on Computer Science Education},
 series = {SIGCSE '19},
 year = {2019},
 isbn = {978-1-4503-5890-3},
 location = {Minneapolis, MN, USA},
 pages = {1276--1276},
 numpages = {1},
 url = {http://doi.acm.org/10.1145/3287324.3293840},
 doi = {10.1145/3287324.3293840},
 acmid = {3293840},
 publisher = {ACM},
 address = {New York, NY, USA},
}